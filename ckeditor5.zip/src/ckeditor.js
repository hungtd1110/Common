/**
 * @license Copyright (c) 2014-2021, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor.js';
import Alignment from '@ckeditor/ckeditor5-alignment/src/alignment.js';
import Autolink from '@ckeditor/ckeditor5-link/src/autolink.js';
import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials.js';
import Link from '@ckeditor/ckeditor5-link/src/link.js';
import MathType from '@wiris/mathtype-ckeditor5';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph.js';

class Editor extends ClassicEditor {}

// Plugins to include in the build.
Editor.builtinPlugins = [
	Alignment,
	Autolink,
	Essentials,
	Link,
	MathType,
	Paragraph
];

export default Editor;
