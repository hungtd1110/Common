# [GrapeCity Documents for Excel](https://www.grapecity.com/documents-api-excel) 

Programmatically create Excel .xlsx spreadsheets with ease in your server or desktop applications. GrapeCity Documents for Excel (GcExcel) is a cross-platform high-speed, small-footprint spreadsheet API library that requires no dependencies on Excel. With full .NET 6 support, you can programmatically generate, load, modify, and convert spreadsheets in .NET 6, .NET Framework, .NET Core/Standard, Mono, and Xamarin. Applications using this spreadsheet API can be deployed to cloud, Windows, Mac, or Linux. The powerful calculation engine and breadth of features means you’ll never have to compromise on design or requirements.

At A Glance:

- Create, load, edit, and save Excel spreadsheets
- Save to .XLSX, PDF, HTML, CSV, and JSON
- Based on the Excel Object Model with zero Excel dependencies
- Deploy locally, inhouse or to Cloud including Azure and AWS
- 450+ Excel Functions and custom functions supported to perform complex calculations
- Use the Templates to create custom Excel reports

Based on the extensive Excel Object Model, the interface-based API allows you to import, calculate, query, generate, and export any spreadsheet scenario. With the VS Tools for Office-style API, you can create custom styles using the same elements as VS Tools for Office.

Using GcExcel, you can create full reports, sorted and filtered tables, sorted and filtered pivot tables, dashboard reports, add charts, slicers, sparklines, conditional formats, import and export Excel templates, convert spreadsheets to PDF and so much more.

GcExcel comes with a full-featured [JavaScript Data viewer control (GcDataViewer)](https://www.npmjs.com/package/@grapecity/gcdataviewer).

If you'd like to remove the watermark and other [trial limitations](https://www.grapecity.com/documents-api-excel/docs/online/LicenseInformation.html), please email us.sales@grapecity.com to request your 30-day evaluation key.
### Complete Client-Server Spreadsheet Solution

You can optionally integrate GcExcel with the SpreadJS JavaScript spreadsheet as a client side editor/viewer solution when working with Excel files for a complete client-server solution. View the complete supported features list [here](https://www.grapecity.com/documents-api-excel/docs/online/support-for-spreadjs-features.html) or download a trial from [NPM](https://www.npmjs.com/package/@grapecity/spread-sheets) or the [SpreadJS](https://www.grapecity.com/spreadjs) page.

## Resources

- [Download 30-day Evaluation](https://www.grapecity.com/documents-api-excel/download)
- [Product Page](https://www.grapecity.com/documents-api-excel)
- [Online Demo](https://www.grapecity.com/documents-api-excel/demos)
- [GcDataViewer Demo](https://www.grapecity.com/documents-api-dataviewer/demos)
- [Getting Started](https://www.grapecity.com/documents-api-excel/docs/online/getting-started.html)
- [License Information](https://www.grapecity.com/documents-api-excel/docs/online/LicenseInformation.html)
- [Licensing FAQ](https://www.grapecity.com/licensing/documents-api)
- [How to get Trial Keys](https://www.grapecity.com/documents-api-excel/docs/online/LicenseInformation.html)
- [GcExcel Blogs](https://www.grapecity.com/blogs/tags/grapecity-documents)
- [Online Documentation](https://www.grapecity.com/documents-api-excel/docs/online/overview.html)
- [Offline Documentation (PDF)](https://www.grapecity.com/documents-api-excel/docs/offlinehelp.pdf)

## Other GrapeCity Document API Solutions

- [Documents for Excel, Java](https://www.grapecity.com/documents-api-excel-java)
- [Documents for PDF](https://www.grapecity.com/documents-api-pdf)
- [Documents for PDF Viewer](https://www.grapecity.com/documents-api-pdf/javascript-pdf-viewer)
- [Documents for Word](https://www.grapecity.com/documents-api-word)
- [Documents for Imaging](https://www.grapecity.com/documents-api-imaging)