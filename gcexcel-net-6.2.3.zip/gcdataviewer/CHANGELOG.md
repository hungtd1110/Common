# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.0] - 07/28/2023

### Added
- Support keyboard shortcuts.(DOCXLS-6805)
- Load SpreadJS .sjs files.(DOCXLS-8005)
- Support numerical count aggregation in status bar.(DOCXLS-8258)

## [1.1.0] - 04/28/2023

### Added

- UI improvements.(DOCXLS-7022)
- Load data files stored on the web/from URL.(DOCXLS-7131)
- Customize the toolbar to remove or reorder buttons.(DOCXLS-7132)
- Support 'Show/Hide Notes' button in toolbar.(DOCXLS-7133)
- Support sorting of values.(DOCXLS-7145)
- Support filtering of values.(DOCXLS-7146)
- Support charts/pictures/shapes/slicers/SpreadJS barcodes.(DOCXLS-7147)
- Support interaction with tables.(DOCXLS-7149)
- Support Pro license.(DOCXLS-7266)

